# 8. Escreva um programa que envie uma mensagem para o usuário indicando uma conexão bem-sucedida.

import pyautogui as tela
from time import sleep

tela.alert('Sua conexão está bem-sucedida! ')
