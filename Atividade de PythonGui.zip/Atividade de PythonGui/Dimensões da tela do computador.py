# Escreva um programa para identificar as dimensões da tela do computado onde está rodando aplicação.

import pyautogui
from time import sleep


tam_da_tela = pyautogui.size()

altura = tam_da_tela.height
largura = tam_da_tela.width


print(f"Altura da tela: {altura} pixels")
print(f"Largura da tela: {largura} pixels")


