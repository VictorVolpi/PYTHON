# 1. Escreva uma função que, dado o valor da conta de um restaurante,
# calcule e exiba a gorjeta do garçom, considerando 10% do valor da conta.

def gorjeta_garcom(valor_conta):

    if valor_conta < 0:
        print("O valor da conta não pode ser negativo.")
        return

    gorjeta = valor_conta * 0.10

    print(f"A gorjeta de 10% para uma conta de R${valor_conta:.2f} é R${gorjeta:.2f}")

valor_da_conta = 2000
gorjeta_garcom(valor_da_conta)
