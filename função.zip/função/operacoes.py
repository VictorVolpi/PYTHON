# 3 – Desenvolva uma função para solicitar dois números e realizar as 4
# operações matemáticas básicas: soma, subtração, divisão e multiplicação.

def soma (num1,num2): return num1 + num2
def sub (num1,num2): return num1 - num2
def mult (num1,num2): return num1 * num2
def div (num1,num2): return num1 / num2

print(soma(100,5))
print(sub(10,5))
print(mult(100,2))
print(div(20,4))
