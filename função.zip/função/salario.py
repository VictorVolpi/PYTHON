    # 2 – Elabore uma função para calcular o salário final de um funcionário de acordo com as seguintes informações:
    # a) se o salário for maior que >=2000 reajuste de 20%.
    # b) se o salário for menor que <2000 reajuste de 15%.
    # O programa deve solicitar o nome do funcionário e o salário do funcionário. Ao término deve exibir:
    # Nome do funcionário, salário antigo, faixa de reajuste, valor do reajuste e salário final.

def calcular_salario_final(nome, salario):

    if salario >= 2000:
        percentual_reajuste = 0.20
        faixa_reajuste = "20%"
    else:
        percentual_reajuste = 0.15
        faixa_reajuste = "15%"

    valor_reajuste = salario * percentual_reajuste
    salario_final = salario + valor_reajuste


    print(f"Nome do Funcionário: {nome}")
    print(f"Salário Antigo: R${salario:.2f}")
    print(f"Faixa de Reajuste: {faixa_reajuste}")
    print(f"Valor do Reajuste: R${valor_reajuste:.2f}")
    print(f"Salário Final: R${salario_final:.2f}")



nome_funcionario = input("Digite o nome do funcionário: ")
salario_funcionario = float(input("Digite o salário do funcionário: R$"))

calcular_salario_final(nome_funcionario, salario_funcionario)
