#7. Crie um script que encontre uma imagem em uma captura de tela e clique na posição onde a imagem foi encontrada:

import pyautogui
from time import sleep

pyautogui.hotkey('windows','e')

sleep(2)
pyautogui.click(1097, 272)

sleep(1)
pyautogui.write('D:\3º ano\QTS\Atividade de PythonGui')

pyautogui.press('enter')
pyautogui.click(1462, 500, clicks=2)