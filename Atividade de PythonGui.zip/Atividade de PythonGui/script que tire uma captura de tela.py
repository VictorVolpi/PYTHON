
#6. Crie um script que tire uma captura de tela da tela inteira e salve-a em um arquivo de imagem:
import pyautogui

capturaTela = pyautogui.screenshot()

capturaTela.save('printTela.png')

