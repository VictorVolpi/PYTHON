# 4. Crie um programa que escreva um texto em um campo de entrada no site do bing, assunto “PyAutoGui”.

import pyautogui
import time
import webbrowser


time.sleep(2)


def search_google(query):
    webbrowser.open("https://www.bing.com")
    time.sleep(2)
    pyautogui.write(query, interval=0.1)
    pyautogui.press('enter')


if __name__ == "__main__":
    search_google("PyAutoGui")
