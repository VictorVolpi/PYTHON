#EXEMPLOS 1

#Dicionário Simples
meuDicionario = {"Chave01": valorChave1, 'chave02': valorChave2, 'chave03': valorChave3, 'chave04': valorchave04}

meuDicionario = {"chave01": 30, 'chave02': 'Texto Puro', 'chave03': 5.1, 'chave04': True}

#EXEMPLO 2

meuDicionario1 = {"chave01": 30, 'chave02': 'Texto Puro', ' chave03': 5.1, 'chave03': True}
valorChave02 =  meuDicionario1.get('chave02')
print(valorChave02)

meuDicionario1['chave05'] = 2023
meuDicionario1['chave06'] = False

print(meuDicionario)

#EXEMPLO 3

dicionarCores = {}
dicionarCores['Green'] = 'Verde'
dicionarCores['Black'] = 'Preto'
dicionarCores['Red'] = 'Vermelho'
dicionarCores['Blue'] = 'Azul'

print(dicionarCores)

#EXEMPLO 4

novoDicionario = {}

for i in range(1,10):
    novoDicionario[i] = i*i
print(novoDicionario)

i = 1

# EXEMPLO 5

while i <5 :
    diconario03[i] = input('Digite um dado para ser adicionado ao diocionario:')   i+=1
    i+=1
print(dicionario03)

#EXEMPLO 6

dicionarCores = {}
dicionarCores['Green'] = 'Verde'
dicionarCores['Black'] = 'Preto'
dicionarCores['Red'] = 'Vermelho'
dicionarCores['Blue'] = 'Azul'

print(dicionarCores)

def dicionarCores ['Red']
print(dicionarCores)

#EXEMPLO 7

dicionarioLinguage = {1: 'Python', 2: 'Java', 3:'JavaScript', 4: 'Lua', 5: 'Rubi'}

for chave in dicionarioLinguage:
    print(chave)
print(30*'#')



dicionarioLinguage = {1: 'Python', 2: 'Java', 3:'JavaScript', 4: 'Lua', 5: 'Rubi'}

for chave in dicionarioLinguage.values():
    print(valor)
print(30*'#')

# EXEMPLO 9

dicionarioLinguage = {1: 'Python', 2: 'Java', 3:'JavaScript', 4: 'Lua', 5: 'Rubi'}

for chave, in dicionarioLinguage.items():
    print(chave,valor)

# EXEMPLO 10

dicionarioMisto = {1:2022, 2: 2023, 'data': '14/07/1981', 'tupla1': ('Ferrari', 'Mercedes', 'MacLaren'),
         'lista1': ['Jan','Fev', 'Mar', 'Abr'], 'status': True, 'tupla2' : ('Red Bull', 'Willians', 'Alpine'),
 'lista2' : ['Mai', 'Jun', 'Ago', 'Set'],'dicionario': {'nome': 'Bob', 'Idade': 27, 'Escolariadade' : 'Superior Comp.'} }

print(dicionarioMisto)









