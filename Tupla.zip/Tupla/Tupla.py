# 1. Escreva um programa que receba uma tupla de numeros inteiros e retorne a soma de todos os elementos da tupla.

def soma_tupla(tupla):
    soma = sum(tupla)
    return soma

tupla1 = (200, 1100, 41, 28, 99, 100)
resultado = soma_tupla(tupla1)
print("A soma dos elementos da tupla é", + resultado)


# 2. Escreva um programa que receba uma tupla de numeros e retorne o maior e o menor valor da tupla.

def maior_e_menor (tupla):
    maior = max (tupla)
    menor = min (tupla)
    return maior, menor

tupla2 = (2023, 2200, 5000, 99, 300, 14, 9, 11, 21, 54, 1)
maior, menor = maior_e_menor(tupla2)
print("O maior valor da tupla é:", maior)
print("O menor valor da tupla é:", menor)


# 3. Escreva uma função que receba uma tupla de strings e retorne uma lista com as strings ordenadas por ordem alfabetica.

def ordernar_uma_tupla(tupla):
    return sorted(tupla)

tupla = ('Elisangela', 'Ricardo''Rafael', 'Thamires', 'Fernanda', 'Camila', 'Beatriz', 'Wanderson', 'Anderson')

lista_ordenada = ordernar_uma_tupla(tupla)
print (lista_ordenada)

# 4. Escreva um programa que receba duas tuplas de numeros e retorne uma nova tupla com a soma dos elementos correspondentes das duas tuplas.

def soma_tuplas(tupla1, tupla2):
    soma = tuple(tupla1[i] + tupla2[i] for i in range(min(len(tupla1), len(tupla2))))
    return soma
tupla4 = (200, 400, 60000, 90000, 13, 27, 93, 100, 205)
tupla5 = (1900, 2026, 1041, 290, 97, 88, 23, 22, 1)
resultado = soma_tuplas(tupla4, tupla5)
print(resultado)

# 5. Escreva um programa que apresente a quantidade de vezes que um determinado registro (N°2) se repete dentro da tupla.

def contar_repeticoes(tupla, registro):
    return tupla.count(registro)


tupla6 = (2, 300, 90, 120, 200, 2, 45, 89, 2, 8000, 900, 999, 56, 2, 77)
registro = 2

repeticoes = contar_repeticoes(tupla6, registro)
print(f'O registro {registro} se repete {repeticoes} vezes na tupla.')

# 6. Contrua um programa que faça a combinação Lista e tupla. crie uma lista com tuplas contendo o nome e o telefone de cada registro.

nomes = ('Clodoaldo', 'Junior', 'Aline', 'Rosangela', 'Vanessa', 'Allan', 'Regiane', 'Elaine')


telefones = (11944758895, 11955548998, 11999999998, 11947791539, 11957798462, 11987799999, 11944788923, 11993564879)

lista_de_registros = []
for nome, telefone in zip(nomes, telefones):
    lista_de_registros.append((nome, telefone))

print("Lista de registros:")
for registro in lista_de_registros:
    print(registro)



# 7. Faça um programa que apresente os elementos de uma tupla a partir de uma posição especifica.
# Posição 5 - 8, posição 2 - até o final. penultima e ultima posição posição 3 - 15, posição 10 - 12)

tupla8 = (2000, 300, True,'312N', '555', '89','1990','300', 'São Paulo Capital', '2023', '257', '999', '654', '712', 'Estação de Itaquera', False, 400,221, 'Estação Guaianazes')


print("Elementos da posição 5 à posição 8:")
print(tupla8[4:8])

print("\nElementos da posição 2 até o final:")
print(tupla8[1:])

print("\nPenúltima e última posição:")
print(tupla8[-3:-1])

print("\nElementos da posição 3 à posição 15:")
print(tupla8[2:15])

print("\nElementos da posição 10 à posição 12:")
print(tupla8[9:12])

#8. Ordene os numeros da tupla a seguir em ordem decrescente utilizando a função sorted().

NumFixos = [45,23,67,12,89,34,56,78,90,10,20,30,70,5,15]
ordenados_decrescente = sorted(NumFixos, reverse=True)
print(ordenados_decrescente)

# 9. Escreva um porgrama que apresente a seguinte tupla em ordem decresente:

palavras =("python", "Programação", "Tupla", "Lista", "dicionario", "String", "Algoritmo", "Computador", "Aplicação", "Desenvolvimento", "Aprender", "Ensinar", "Conhecimento", "Inteligencia", "Artiicial")

tupla_decrescente = sorted(palavras, reverse=True)

print("Tupla Decrescente")

for palavra in tupla_decrescente:

    print (palavras)
# 10. Faça um programa que distibua os valores de uma tupla em variaveis individuais "UNPACKING"

times_Futebol = ("Real Madrid", "Barcelona", "Manchester City", "Liverpool", "Bayer de Munique", "PSG", "Chelsea", "Juventus", "Borussia Dortmund", "Atlético de Madrid")

time1,time2, time3, time4, time5, time6, time7, time8, time9, time10 = times_Futebol

print("Times de Futebol:")
print("1", time1)
print("2", time2)
print("3", time3)
print("4", time4)
print("5", time5)
print("6", time6)
print("7", time7)
print("8", time8)
print("9", time9)
print("10", time10)


# 11. Remova os dois ultimos numeros de tupla exibida abaixo.

Numeros = (1981,2222,2014,1970,1982,233,567,2000,99,89)

Ultimos_Numeros_removidos = Numeros [: -2]

print(Ultimos_Numeros_removidos)

# 12. Remova o time da posição 5 da tupla a seguir.

timesFutebol = ("Real Madrid", "Barcelona", "Manchester City", "Liverpool", "Bayer de Munique", "PSG", "Chelsea", "Juventus", "Borussia Dortmund", "Atlético de Madrid")
lista_times = list(timesFutebol)
del lista_times[5]
timesFutebol = tuple (lista_times)
print(timesFutebol)

# 13. Remova as seguintes times da tupla "timesFutebol": Real Madrid e Juventus.

timesFutebol = ("Real Madrid", "Barcelona", "Manchester City", "Liverpool", "Bayer de Munique", "PSG", "Chelsea", "Juventus", "Borussia Dortmund", "Atlético de Madrid")
timesFutebol = tuple ([time for time in timesFutebol if time not in ("Real Madrid,", "Juventus")])

print(timesFutebol)