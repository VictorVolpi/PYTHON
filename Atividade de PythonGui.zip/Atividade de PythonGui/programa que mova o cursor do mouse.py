# 3. Crie um programa que mova o cursor do mouse para a bandeja do sistema e clique no calendário do sistema (Windows).

import pyautogui

pyautogui.position (1800, 1080)
pyautogui.click(1800, 1080)