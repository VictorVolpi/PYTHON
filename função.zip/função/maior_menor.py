#5 - Escreva um programa que leia três números e que imprima o maior e o menor.

def encontrar_maior_menor():
    num1 = float(input("Digite o primeiro numero:"))
    num2 = float(input("Digite o sergundo numero:"))
    num3 = float(input("Digite o terceiro numero:"))

    maior = max(num1, num2, num3 )
    menor = min(num1, num2, num3 )


    print("o maior numero é:", maior)
    print("o menor numero é:", menor)

encontrar_maior_menor()