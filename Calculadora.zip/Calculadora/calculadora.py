# Calculadora feita em python!
# Totalmente editada com para melhor fluidez do usuario!
# Obtendo as  6 operações basicas!

def adicao(a, b):
    """Realiza a adição de dois números"""
    return a + b

def subtracao(a, b):
    """Realiza a subtração de dois números"""
    return a - b

def multiplicacao(a, b):
    """Realiza a multiplicação de dois números"""
    return a * b

def divisao(a, b):
    """Realiza a divisão de dois números"""
    if b == 0:
        return "Erro: Divisão por zero não é permitida!"
    return a / b

def potencia(a, b):
    """Calcula a potência de um número"""
    return a ** b

def raiz_quadrada(a):
    """Calcula a raiz quadrada de um número"""
    if a < 0:
        return "Erro: Não é possível calcular raiz quadrada de número negativo!"
    return a ** 0.5

def mostrar_menu():
    """Exibe o menu de operações disponíveis"""
    print("\n" + "="*50)
    print("🧮 CALCULADORA PYTHON")
    print("="*50)
    print("Escolha uma operação:")
    print("1. Adição (+)")
    print("2. Subtração (-)")
    print("3. Multiplicação (×)")
    print("4. Divisão (÷)")
    print("5. Potência (^)")
    print("6. Raiz Quadrada (√)")
    print("0. Sair")
    print("="*50)

def obter_numero(mensagem):
    """Obtém um número válido do usuário"""
    while True:
        try:
            return float(input(mensagem))
        except ValueError:
            print("❌ Por favor, digite um número válido!")

def calculadora():
    """Função principal da calculadora"""
    print("Bem-vindo à Calculadora Python! 🎉")
    
    while True:
        mostrar_menu()
        
        try:
            opcao = input("Digite sua escolha (0-6): ").strip()
            
            if opcao == '0':
                print("👋 Obrigado por usar a calculadora! Até logo!")
                break
            
            elif opcao in ['1', '2', '3', '4', '5']:
                num1 = obter_numero("Digite o primeiro número: ")
                num2 = obter_numero("Digite o segundo número: ")
                
                if opcao == '1':
                    resultado = adicao(num1, num2)
                    print(f"✅ {num1} + {num2} = {resultado}")
                
                elif opcao == '2':
                    resultado = subtracao(num1, num2)
                    print(f"✅ {num1} - {num2} = {resultado}")
                
                elif opcao == '3':
                    resultado = multiplicacao(num1, num2)
                    print(f"✅ {num1} × {num2} = {resultado}")
                
                elif opcao == '4':
                    resultado = divisao(num1, num2)
                    print(f"✅ {num1} ÷ {num2} = {resultado}")
                
                elif opcao == '5':
                    resultado = potencia(num1, num2)
                    print(f"✅ {num1} ^ {num2} = {resultado}")
            
            elif opcao == '6':
                num = obter_numero("Digite o número para calcular a raiz quadrada: ")
                resultado = raiz_quadrada(num)
                print(f"✅ √{num} = {resultado}")
            
            else:
                print("❌ Opção inválida! Por favor, escolha uma opção de 0 a 6.")
            
            if opcao != '0':
                continuar = input("\nDeseja fazer outro cálculo? (s/n): ").lower().strip()
                if continuar not in ['s', 'sim', 'y', 'yes']:
                    print("👋 Obrigado por usar a calculadora! Até logo!")
                    break
        
        except KeyboardInterrupt:
            print("\n\n👋 Calculadora encerrada pelo usuário. Até logo!")
            break
        except Exception as e:
            print(f"❌ Ocorreu um erro inesperado: {e}")


if __name__ == "__main__":
    calculadora()
