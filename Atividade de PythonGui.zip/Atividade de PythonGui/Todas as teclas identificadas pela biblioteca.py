# 2. Elabore um programa que apresente o nome de todas as teclas identificadas pela biblioteca PyAutoGui.

import pyautogui

teclasUsadas = pyautogui.KEYBOARD_KEYS

print('Todas as Teclas Usadas:')

for teclas in teclasUsadas:
    print(teclas)