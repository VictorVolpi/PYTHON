# 4 - Construa uma função para a seguinte situação que o usuário deve
# digitar uma opção:
# 1 – Calculo da Area do Trapézio.
# 2 – Calculo da Area do Círculo.
# 3 – Calculo da Area do Triangulo.
# 4 – Calculo da Area do Retângulo.
# 5 – Calculo da Area do Losango.
# 0 – Sair do Programa


# 1 – Calculo da Area do Trapézio.
def area_trapezio(base_maior, base_menor, altura):
        area = (base_maior + base_menor) * altura / 2
        return area

base_maior = float(input("Digite a base maior: "))
base_menor = float(input("Digite a base menor: "))
altura = float(input("Digite a altura: "))


area = area_trapezio(base_maior, base_menor, altura)
print("A área do trapézio é:", area)

# 2 – Calculo da Area do Círculo.

import math

def area_circulo(raio):
    return math.pi * raio ** 2


raio = float(input("Digite o raio do círculo: "))
area = area_circulo(raio)
print("A área do círculo é:", area)

# 3 – Calculo da Area do Triangulo.

def area_triangulo(base, altura):
    return (base * altura) / 2


base = float(input("Digite a base do triângulo: "))
altura = float(input("Digite a altura do triângulo: "))
area = area_triangulo(base, altura)
print("A área do triângulo é:", area)

# 4 – Calculo da Area do Retângulo.

def area_retangulo(largura, altura):
    return largura * altura


largura = float(input("Digite a largura do retângulo: "))
altura = float(input("Digite a altura do retângulo: "))
area = area_retangulo(largura, altura)
print("A área do retângulo é:", area)


# 5 – Calculo da Area do Losango.

def area_losango(diagonal1, diagonal2):
    return (diagonal1 * diagonal2) / 2

diagonal1 = float(input("Digite a medida da primeira diagonal do losango: "))
diagonal2 = float(input("Digite a medida da segunda diagonal do losango: "))
area = area_losango(diagonal1, diagonal2)
print("A área do losango é:", area)







