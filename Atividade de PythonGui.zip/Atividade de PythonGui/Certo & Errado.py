# 10.Escreva um programa que tenha três opções (Janeiro, Fevereiro,
# Março), as escolha correta deve ser a alternativa Março. Mostre a
# mensagem de “Opção correta” quando o usuário escolher a opção
# Março e “Opção errada” quando o usuário escolher uma opção
# diferente.

import pyautogui as tela
oi = tela.confirm(text='', title='', buttons=['JANEIRO','FEVEREIRO','MARÇO'])


if(oi == 'JANEIRO'):
    tela.alert('ERROU')
elif (oi == 'FEVEREIRO'):
    tela.alert('ERROU')
elif(oi == 'MARÇO'):
    tela.alert('CORRETO')
