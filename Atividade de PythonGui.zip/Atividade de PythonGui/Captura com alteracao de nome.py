# 11.Faça um programa que realize a captura de tela Screeshot depois
# de 3 Segundos, salve a imagem com o nome de captura 072024

import pyautogui
import time

time.sleep(3)

screenshot = pyautogui.screenshot()

arquivo = 'captura072024.png'

screenshot.save(arquivo)

print(f'Captura de tela salva como {arquivo}')