#9. Escreva um programa que apresente três botões de escolha (Sim, Não e Talvez)
# e apresente a opção escolhida pelo usuário em uma mensagem de alert.

import pyautogui as tela
oi = tela.confirm(text='', title='', buttons=['SIM', 'TALVEZ','NÃO'])

if(oi == 'SIM'):
    tela.alert('O Usuario Escolheu a opção Sim')
elif(oi == 'TALVEZ'):
    tela.alert('O Usuario Escolheu a opção Talvez')
elif(oi == 'NÃO'):
    tela.alert('O Usuario Escolheu a opção Não')