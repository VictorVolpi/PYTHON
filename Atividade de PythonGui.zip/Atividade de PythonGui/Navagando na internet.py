# 12. Elabore um script automatizado que o cursor do mouse click em um
# navegador de internet e seja direcionado para algum site. Coloque se
# necessário a duração dos eventos para que o script não fique rápido.

import time
import pyautogui

pyautogui.press('windows')

pyautogui.write('google')

pyautogui.press('enter')

pyautogui.click(380, 64)

pyautogui.write('Poki')

pyautogui.press('enter')

time.sleep(2)

pyautogui.click(256, 301)